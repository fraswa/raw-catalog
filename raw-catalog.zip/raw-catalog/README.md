# RAW Catalog

A self-hosted web catalog for RAW photographs on a Linux server. The server recursively reads a mounted photo folder, stores camera/lens and exposure metadata in MariaDB, and generates JPEG thumbnails and screen-size previews. Search by camera, lens, their combination, or filename/folder. Click any result for a full-window viewer with left/right navigation, EXIF details, and a browser full-screen button where supported.

## Start on Linux

Requirements: Docker Engine with the Compose v2 plugin, Python 3 for the one-time setup, and a locally mounted photo directory. NAS folders work when already mounted on the Linux host. Internet access is needed for the initial image build; runtime has no cloud dependency.

Extract the archive, enter its folder, then run:

```bash
cd raw-catalog
python3 setup.py --photos /srv/photos
docker compose up -d --build
```

Replace `/srv/photos` with your actual photo folder. Setup asks for the web password and generates independent database passwords and a session secret in a mode-600 `.env` file. It refuses to overwrite an existing configuration.

Open `http://YOUR_SERVER_IP:8080`, sign in with the password you chose, then click **Index photos**. Open the **Indexer** panel at the bottom for counts, errors, rebuild mode, and cancellation. Files already indexed become searchable while the scan continues; refresh the gallery to see new files before the scan finishes. Completion refreshes results automatically unless the viewer is open.

The photo directory is mounted **read-only** in the indexer. The web service has no access to the source directory at all. This app has no original-file deletion, modification, or download endpoint.

## Storage and permissions

- `database` Docker volume: MariaDB data, metadata records, scan status.
- `previews` Docker volume: sharded JPEG thumbnail/preview cache.
- `/photos` inside the worker: your host photo folder, mounted read-only.
- Container processes use UID/GID `10001`. They need read access to photos and traversal access to directories. Match your existing file permissions or add the appropriate host group to the worker. Do not make your entire photo archive world-writable.

For a photo folder readable by a host group such as GID `1000`, create `compose.override.yaml`:

```yaml
services:
  worker:
    group_add:
      - "1000"
```

Then run `docker compose up -d`. Docker named volumes are initialized with the image's cache directory ownership. If reusing a volume from another application, make its cache directory writable by UID 10001.

Ensure NAS mounts are active before starting containers. Compose refuses to create a nonexistent host folder. An existing but unmounted mountpoint may still be empty; no scan ever deletes old catalog entries, so an unavailable archive cannot purge your database.

## Searching and viewing

- **Camera** and **Lens** use exact metadata-derived labels. Selecting both means AND.
- Dropdown counts reflect the other selected filter and filename/folder search.
- **Filename or folder** is a literal case-insensitive substring search with MariaDB's default collation. `%` and `_` are not SQL wildcard operators in this field.
- Results use cursor pagination, 60 photos at a time, newest database IDs first. This is indexing order, not capture-date order.
- Capture dates and recorded EXIF values appear in the gallery/details. EXIF timestamps are kept as recorded, without assuming a timezone.
- Click a thumbnail for the full-window viewer. Use arrow keys or buttons to move through the matching set; the next result page loads as needed. Escape/Close exits the viewer; the browser Full screen control hides browser chrome when available.
- Full-screen previews are JPEG derivatives up to **2560 pixels on the longest side**, not full-resolution RAW downloads. Increase `PREVIEW_EDGE` in `.env` and rebuild previews if wanted. Small embedded previews are never enlarged.
- Manual or adapted lenses without identifying EXIF appear as **Unknown lens**. Labels can vary between cameras and firmware; this version does not manually merge aliases.

## Indexing behavior

Metadata is read in batches with ExifTool. Preview extraction tries embedded `JpgFromRaw` and `PreviewImage` JPEGs, then LibRaw/rawpy's thumbnail; if no usable thumbnail is available to LibRaw, it develops a half-size sRGB JPEG using the camera white balance. RAW support depends on the installed ExifTool and LibRaw versions. An extension being recognized does not guarantee that every camera variant can be decoded.

Recognized extensions: CR2, CR3, CRW, NEF, NRW, ARW, SRF, SR2, DNG, RAF, ORF, RW2, RWL, PEF, PTX, SRW, 3FR, FFF, IIQ, KDC, DCR, MOS, MRW, RAW, X3F. JPEG/TIFF sidecars and XMP sidecars are not imported in this version.

- Folders are walked recursively; symbolic links are skipped to avoid loops and leaving the configured tree.
- Paths are catalog identities. Size + nanosecond modification time determine whether a file has changed; there is no expensive full-file checksum or duplicate detection.
- Unchanged files with healthy previews are skipped. Missing previews and preview errors are retried on the next scan.
- **Rebuild metadata and previews** forces a full pass, useful after changing preview size or extraction software, or if a file changed while retaining its original size/mtime.
- A damaged or unsupported preview does not discard successfully read metadata. The result remains searchable with an unavailable-preview tile and the error in file details.
- Files whose metadata cannot be read are logged and counted as errors. Re-run after fixing the source or permissions.
- Scans are serialized in the database queue; the worker also holds a filesystem lock. Run one worker with the shared preview volume.
- Cancellation preserves completed work. The current ExifTool/RAW operation may take time to finish before cancellation is noticed.
- A worker restart marks interrupted scans as failed. Click Index photos again to resume incrementally.
- Moved/deleted source paths remain in the catalog, including cached previews. There is deliberately no automatic pruning; a move currently creates a new record at the new path. Old cache versions are also retained. These can consume extra disk after repeated edits/rebuilds.

The architecture keeps directory batches small and uses indexed camera/lens columns and keyset pagination. Initial indexing still reads every RAW and generates JPEGs; large archives may take many hours or days depending on storage, format, and embedded previews. Filename/path substring searches and total counts may take longer on very large catalogs. No benchmark on your archive has been performed. Store the database and cache on an SSD if possible and budget disk space for two JPEGs per photo; measure a representative sample before indexing a very large archive.

## Configuration

Edit `.env`, then run `docker compose up -d`:

| Setting | Default / purpose |
|---|---|
| `PHOTO_PATH` | Existing absolute photo folder on Linux |
| `WEB_PORT` | `8080` |
| `BIND_IP` | `0.0.0.0` (all host interfaces); set `127.0.0.1` for a local reverse proxy |
| `CATALOG_PASSWORD` | Shared web login password, at least 12 characters |
| `SECRET_KEY` | Session signing secret, at least 32 characters |
| `DB_PASSWORD` / `DB_ROOT_PASSWORD` | Generated hex passwords; preserve after database initialization |
| `PREVIEW_EDGE` | `2560`; run a forced rebuild after changing |
| `COOKIE_SECURE` | `false` for LAN HTTP; set `true` when using HTTPS |

If you change the catalog password, rotate `SECRET_KEY` too to invalidate existing sessions. Changing DB passwords in `.env` alone does not update users inside an already initialized MariaDB volume.

This is a single-user/private-network application. Use a VPN or HTTPS reverse proxy for remote access. The login password and session cookie must not travel over public HTTP. The app provides password login, HTTP-only SameSite cookies, CSRF validation, and protected preview routes; it does not provide multiple users, 2FA, or built-in login rate limiting. Configure request limits at your reverse proxy if exposed beyond a trusted network. MariaDB has no published host port in the supplied Compose file.

## Operations

```bash
# Container health and logs
docker compose ps
docker compose logs -f worker
docker compose logs --tail=100 web db

# Stop without deleting data
docker compose down

# Rebuild application image after source changes
docker compose up -d --build
```

For a consistent database backup, stop the worker briefly and dump MariaDB:

```bash
docker compose stop worker
docker compose exec -T db sh -c 'exec mariadb-dump -u root -p"$MARIADB_ROOT_PASSWORD" --single-transaction rawcatalog' > rawcatalog.sql
docker compose start worker
```

Also back up `.env`. Preview caches can be backed up to avoid regeneration. Originals require their own independent backup. `docker compose down -v` destroys the database and preview volumes; do not use it for routine restarts. This initial version creates its schema at startup; future schema changes need explicit migrations.

## Source layout

- `app/db.py`: schema and sessions (SQLAlchemy + PyMySQL).
- `app/worker.py`: recursive scans, incremental updates, queue processing.
- `app/imaging.py`: ExifTool extraction, RAW fallback, orientation, JPEG cache.
- `app/web.py`: authenticated API, filters, media serving, scan controls.
- `app/static/`: responsive gallery and full-screen viewer; no external frontend assets or services.
- `compose.yaml` / `Dockerfile`: Linux deployment with MariaDB 11.4.
- `setup.py`: safe initial configuration.
- `tests/test_catalog.py`: API and indexing regression tests.

The SQLAlchemy schema uses MySQL-compatible column types and indexes. MariaDB is the supplied deployment target. To use an existing MySQL 8 server, override `DATABASE_URL` for web and worker with a `mysql+pymysql://...` URL, remove their dependency on the bundled `db` service, and provide an empty application database/user with schema-creation privileges. Keep any non-hex password URL-encoded. Back up before switching databases.

## Verification and limitations

Run the tests in a Python environment with the application requirements installed:

```bash
python3 -m pip install -r requirements.txt pytest==8.4.2
python3 -m pytest -q
```

The delivered tests cover password/CSRF checks, combined camera/lens filters, cursor pagination, literal search escaping, dependent facets, scan queue/cancel behavior, recursive scanning, symlink skipping, unchanged-file skipping, missing-preview repair, changed-file updates, preview-error retention, unavailable-root handling, orientation, and authenticated JPEG delivery. Tests use an isolated temporary SQLite database and fixture metadata/preview extraction. They never connect to your production database or touch your photo archive.

Python compilation and JavaScript syntax were also checked during development. This build has not been run against a live MariaDB server or Docker daemon, browser interactions have not been end-to-end tested, and no real RAW sample was supplied. Test a small representative folder containing your camera formats before a full archive scan. Unsupported/new cameras may require newer ExifTool or rawpy/LibRaw packages; some special RAW variants cannot be previewed by this stack.

References: [ExifTool](https://exiftool.org/) and [rawpy preview and development API](https://letmaik.github.io/rawpy/api/rawpy.RawPy.html).
